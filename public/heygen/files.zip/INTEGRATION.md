# 📘 Exemples d'Intégration - Assistant Avatar dans GOB Apps

Guide pratique pour intégrer l'Assistant Avatar dans vos pages GOB Apps existantes.

## 🎯 Options d'Intégration

### Option 1: iFrame Simple (Plus Rapide)
### Option 2: Composant React (Intégration Profonde)
### Option 3: Web Component (Réutilisable)
### Option 4: API Client JavaScript (Contrôle Total)

---

## 1️⃣ iFrame Simple

### Installation

Ajouter dans n'importe quelle page HTML de GOB Apps:

```html
<!-- Page: gobapps.com/nouvelle-page.html -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Assistant Avatar - GOB Apps</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .avatar-container {
            width: 100%;
            height: 100vh;
            border: none;
        }
        
        /* Style optionnel pour header GOB */
        .gob-header {
            background: linear-gradient(135deg, #1a237e, #0d47a1);
            color: white;
            padding: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Header GOB Apps (optionnel) -->
    <div class="gob-header">
        <h1>🤖 Assistant Avatar IA</h1>
        <p>Desjardins Gestion de Patrimoine - Groupe Ouellet Bolduc</p>
    </div>

    <!-- iFrame Assistant Avatar -->
    <iframe 
        class="avatar-container"
        src="https://avatar.gobapps.com/avatar-assistant.html"
        title="Assistant Avatar GOB"
        allow="microphone; camera"
        loading="lazy">
    </iframe>

    <script>
        // Communication avec iFrame (optionnel)
        window.addEventListener('message', function(event) {
            // Vérifier origine
            if (event.origin !== 'https://avatar.gobapps.com') return;
            
            // Gérer messages de l'avatar
            console.log('Message reçu:', event.data);
            
            if (event.data.type === 'avatar_ready') {
                console.log('Avatar prêt');
            }
        });
    </script>
</body>
</html>
```

### Avantages
✅ Installation en 2 minutes  
✅ Isolation complète  
✅ Pas de conflits CSS/JS  
✅ Mises à jour automatiques  

### Inconvénients
❌ Personnalisation limitée  
❌ Communication par postMessage  

---

## 2️⃣ Composant React

### Installation dans Application React Existante

```jsx
// components/AvatarAssistant.jsx

import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';

const AvatarAssistant = ({ 
  apiUrl = 'https://api.gobapps.com',
  defaultAvatar = null,
  theme = 'light',
  onMessageSent = null,
  onVideoReady = null
}) => {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [avatars, setAvatars] = useState([]);
  const [selectedAvatar, setSelectedAvatar] = useState(defaultAvatar);
  const [isLoading, setIsLoading] = useState(false);
  const [videoUrl, setVideoUrl] = useState(null);
  const videoRef = useRef(null);

  // Charger avatars au montage
  useEffect(() => {
    loadAvatars();
  }, []);

  const loadAvatars = async () => {
    try {
      const response = await axios.get(`${apiUrl}/api/heygen/avatars`);
      setAvatars(response.data.data || []);
      
      if (!selectedAvatar && response.data.data.length > 0) {
        setSelectedAvatar(response.data.data[0].id);
      }
    } catch (error) {
      console.error('Erreur chargement avatars:', error);
    }
  };

  const sendMessage = async () => {
    if (!inputText.trim() || !selectedAvatar || isLoading) return;

    const userMessage = { 
      role: 'user', 
      content: inputText,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    try {
      // 1. Appel LLM
      const llmResponse = await axios.post(`${apiUrl}/api/llm/chat`, {
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: 'Assistant financier GOB' },
          ...messages,
          userMessage
        ]
      });

      const assistantMessage = {
        role: 'assistant',
        content: llmResponse.data.response,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, assistantMessage]);

      // 2. Générer vidéo
      const videoResponse = await axios.post(`${apiUrl}/api/heygen/generate-video`, {
        avatar_id: selectedAvatar,
        text: llmResponse.data.response,
        voice: 'fr_fr_emma'
      });

      // 3. Poll pour URL vidéo
      const videoId = videoResponse.data.video_id;
      await pollVideoStatus(videoId);

      if (onMessageSent) {
        onMessageSent(userMessage, assistantMessage);
      }

    } catch (error) {
      console.error('Erreur:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Désolé, une erreur s\'est produite.',
        error: true
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const pollVideoStatus = async (videoId, attempts = 0) => {
    if (attempts > 60) return; // Max 3 minutes

    try {
      const response = await axios.get(`${apiUrl}/api/heygen/video-status/${videoId}`);
      
      if (response.data.status === 'completed' && response.data.video_url) {
        setVideoUrl(response.data.video_url);
        
        if (videoRef.current) {
          videoRef.current.src = response.data.video_url;
          videoRef.current.play();
        }

        if (onVideoReady) {
          onVideoReady(response.data.video_url);
        }
      } else if (response.data.status !== 'failed') {
        setTimeout(() => pollVideoStatus(videoId, attempts + 1), 3000);
      }
    } catch (error) {
      console.error('Erreur polling:', error);
    }
  };

  return (
    <div className={`avatar-assistant theme-${theme}`}>
      <div className="video-section">
        {videoUrl ? (
          <video 
            ref={videoRef} 
            controls 
            className="avatar-video"
          />
        ) : (
          <div className="avatar-placeholder">
            <div className="avatar-icon">👤</div>
            <p>Sélectionnez un avatar</p>
          </div>
        )}
      </div>

      <div className="chat-section">
        <select 
          value={selectedAvatar || ''} 
          onChange={(e) => setSelectedAvatar(e.target.value)}
          className="avatar-select"
        >
          <option value="">Choisir un avatar...</option>
          {avatars.map(avatar => (
            <option key={avatar.id} value={avatar.id}>
              {avatar.name}
            </option>
          ))}
        </select>

        <div className="messages">
          {messages.map((msg, idx) => (
            <div key={idx} className={`message ${msg.role}`}>
              <div className="message-content">{msg.content}</div>
              <div className="message-time">
                {new Date(msg.timestamp).toLocaleTimeString('fr-FR')}
              </div>
            </div>
          ))}
        </div>

        {isLoading && (
          <div className="loading">
            <div className="spinner"></div>
            <span>Génération en cours...</span>
          </div>
        )}

        <div className="input-group">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
            placeholder="Tapez votre message..."
            disabled={isLoading}
          />
          <button onClick={sendMessage} disabled={isLoading || !inputText.trim()}>
            Envoyer
          </button>
        </div>
      </div>
    </div>
  );
};

export default AvatarAssistant;
```

### Utilisation dans GOB Apps

```jsx
// pages/AvatarPage.jsx

import React from 'react';
import AvatarAssistant from '../components/AvatarAssistant';

function AvatarPage() {
  const handleMessageSent = (userMsg, assistantMsg) => {
    console.log('Nouvelle conversation:', userMsg, assistantMsg);
    // Analytics, logging, etc.
  };

  const handleVideoReady = (videoUrl) => {
    console.log('Vidéo prête:', videoUrl);
    // Afficher notification, etc.
  };

  return (
    <div className="page-container">
      <header className="gob-header">
        <h1>Assistant Avatar IA</h1>
      </header>

      <AvatarAssistant
        apiUrl="https://api.gobapps.com"
        theme="dark"
        onMessageSent={handleMessageSent}
        onVideoReady={handleVideoReady}
      />
    </div>
  );
}

export default AvatarPage;
```

### Styles CSS

```css
/* styles/AvatarAssistant.css */

.avatar-assistant {
  display: grid;
  grid-template-columns: 1fr 400px;
  gap: 20px;
  height: 600px;
  font-family: 'Segoe UI', sans-serif;
}

.video-section {
  background: #000;
  border-radius: 12px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
}

.avatar-video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.avatar-placeholder {
  color: white;
  text-align: center;
}

.avatar-icon {
  font-size: 80px;
  margin-bottom: 20px;
}

.chat-section {
  display: flex;
  flex-direction: column;
  background: #f5f5f5;
  border-radius: 12px;
  padding: 20px;
}

.avatar-select {
  margin-bottom: 20px;
  padding: 10px;
  border-radius: 8px;
  border: 2px solid #ddd;
}

.messages {
  flex: 1;
  overflow-y: auto;
  margin-bottom: 20px;
}

.message {
  margin-bottom: 16px;
  padding: 12px;
  border-radius: 8px;
  background: white;
}

.message.user {
  background: linear-gradient(135deg, #1a237e, #0d47a1);
  color: white;
  margin-left: auto;
  max-width: 80%;
}

.message.assistant {
  background: white;
  max-width: 80%;
}

.message-time {
  font-size: 11px;
  opacity: 0.7;
  margin-top: 4px;
}

.loading {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  background: rgba(0,0,0,0.05);
  border-radius: 8px;
  margin-bottom: 12px;
}

.spinner {
  width: 20px;
  height: 20px;
  border: 3px solid #ddd;
  border-top-color: #1a237e;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.input-group {
  display: flex;
  gap: 12px;
}

.input-group input {
  flex: 1;
  padding: 12px 16px;
  border: 2px solid #ddd;
  border-radius: 24px;
  font-size: 14px;
}

.input-group button {
  padding: 12px 24px;
  background: linear-gradient(135deg, #00bcd4, #00acc1);
  color: white;
  border: none;
  border-radius: 24px;
  cursor: pointer;
  font-weight: 600;
}

.input-group button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
```

---

## 3️⃣ Web Component

### Définition du Web Component

```javascript
// avatar-assistant-component.js

class AvatarAssistant extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    
    this.apiUrl = this.getAttribute('api-url') || 'https://api.gobapps.com';
    this.theme = this.getAttribute('theme') || 'light';
  }

  connectedCallback() {
    this.render();
    this.setupEventListeners();
    this.loadAvatars();
  }

  render() {
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          font-family: 'Segoe UI', sans-serif;
        }
        
        .container {
          display: grid;
          grid-template-columns: 2fr 1fr;
          gap: 20px;
          height: 600px;
        }
        
        /* Styles similaires à la version standalone */
        /* ... copier les styles de avatar-assistant.html ... */
      </style>

      <div class="container">
        <div class="video-section">
          <video id="videoPlayer"></video>
          <div class="placeholder">
            <div class="icon">👤</div>
            <p>Assistant Avatar Prêt</p>
          </div>
        </div>

        <div class="chat-section">
          <select id="avatarSelect">
            <option>Chargement...</option>
          </select>
          
          <div id="messages"></div>
          
          <div class="input-area">
            <input type="text" id="messageInput" placeholder="Votre message...">
            <button id="sendBtn">Envoyer</button>
          </div>
        </div>
      </div>
    `;
  }

  setupEventListeners() {
    const sendBtn = this.shadowRoot.getElementById('sendBtn');
    const input = this.shadowRoot.getElementById('messageInput');

    sendBtn.addEventListener('click', () => this.sendMessage());
    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.sendMessage();
    });
  }

  async loadAvatars() {
    try {
      const response = await fetch(`${this.apiUrl}/api/heygen/avatars`);
      const data = await response.json();
      
      const select = this.shadowRoot.getElementById('avatarSelect');
      select.innerHTML = '<option value="">Sélectionner...</option>';
      
      data.data.forEach(avatar => {
        const option = document.createElement('option');
        option.value = avatar.id;
        option.textContent = avatar.name;
        select.appendChild(option);
      });
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  async sendMessage() {
    const input = this.shadowRoot.getElementById('messageInput');
    const text = input.value.trim();
    
    if (!text) return;

    // Ajouter message utilisateur
    this.addMessage('user', text);
    input.value = '';

    // Appeler API
    try {
      const response = await fetch(`${this.apiUrl}/api/llm/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'gpt-4o',
          messages: [
            { role: 'user', content: text }
          ]
        })
      });

      const data = await response.json();
      this.addMessage('assistant', data.response);

      // Générer vidéo
      const avatarSelect = this.shadowRoot.getElementById('avatarSelect');
      if (avatarSelect.value) {
        await this.generateVideo(avatarSelect.value, data.response);
      }

    } catch (error) {
      console.error('Erreur:', error);
      this.addMessage('assistant', 'Erreur lors du traitement.');
    }
  }

  addMessage(role, content) {
    const messagesDiv = this.shadowRoot.getElementById('messages');
    const messageEl = document.createElement('div');
    messageEl.className = `message ${role}`;
    messageEl.innerHTML = `
      <div class="content">${content}</div>
      <div class="time">${new Date().toLocaleTimeString('fr-FR')}</div>
    `;
    messagesDiv.appendChild(messageEl);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
  }

  async generateVideo(avatarId, text) {
    try {
      const response = await fetch(`${this.apiUrl}/api/heygen/generate-video`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          avatar_id: avatarId,
          text: text
        })
      });

      const data = await response.json();
      await this.pollVideoStatus(data.video_id);

    } catch (error) {
      console.error('Erreur vidéo:', error);
    }
  }

  async pollVideoStatus(videoId, attempts = 0) {
    if (attempts > 60) return;

    try {
      const response = await fetch(`${this.apiUrl}/api/heygen/video-status/${videoId}`);
      const data = await response.json();

      if (data.status === 'completed' && data.video_url) {
        const video = this.shadowRoot.getElementById('videoPlayer');
        video.src = data.video_url;
        video.play();
      } else if (data.status !== 'failed') {
        setTimeout(() => this.pollVideoStatus(videoId, attempts + 1), 3000);
      }
    } catch (error) {
      console.error('Erreur polling:', error);
    }
  }
}

customElements.define('avatar-assistant', AvatarAssistant);
```

### Utilisation

```html
<!-- Dans n'importe quelle page GOB Apps -->
<!DOCTYPE html>
<html>
<head>
    <title>Assistant Avatar</title>
    <script src="/js/avatar-assistant-component.js"></script>
</head>
<body>
    <!-- Utilisation simple -->
    <avatar-assistant 
        api-url="https://api.gobapps.com"
        theme="dark">
    </avatar-assistant>
</body>
</html>
```

---

## 4️⃣ API Client JavaScript

### Client JavaScript Autonome

```javascript
// gob-avatar-client.js

class GOBAvatarClient {
  constructor(config = {}) {
    this.apiUrl = config.apiUrl || 'https://api.gobapps.com';
    this.sessionId = this.generateSessionId();
    this.conversationHistory = [];
  }

  generateSessionId() {
    return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  async getAvatars() {
    const response = await fetch(`${this.apiUrl}/api/heygen/avatars`);
    return response.json();
  }

  async sendMessage(text, avatarId, options = {}) {
    const model = options.model || 'gpt-4o';
    const voice = options.voice || 'fr_fr_emma';

    // 1. Appel LLM
    const llmResponse = await fetch(`${this.apiUrl}/api/llm/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: model,
        messages: [
          { role: 'system', content: options.systemPrompt || 'Assistant GOB' },
          ...this.conversationHistory,
          { role: 'user', content: text }
        ],
        sessionId: this.sessionId
      })
    });

    const llmData = await llmResponse.json();
    const assistantResponse = llmData.response;

    // Sauvegarder historique
    this.conversationHistory.push(
      { role: 'user', content: text },
      { role: 'assistant', content: assistantResponse }
    );

    // 2. Générer vidéo si avatar fourni
    let videoJobId = null;
    if (avatarId) {
      const videoResponse = await fetch(`${this.apiUrl}/api/heygen/generate-video`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          avatar_id: avatarId,
          text: assistantResponse,
          voice: voice
        })
      });

      const videoData = await videoResponse.json();
      videoJobId = videoData.video_id;
    }

    return {
      text: assistantResponse,
      videoJobId: videoJobId,
      sessionId: this.sessionId
    };
  }

  async getVideoStatus(videoId) {
    const response = await fetch(`${this.apiUrl}/api/heygen/video-status/${videoId}`);
    return response.json();
  }

  async waitForVideo(videoId, timeout = 180000) {
    const startTime = Date.now();

    return new Promise((resolve, reject) => {
      const checkStatus = async () => {
        if (Date.now() - startTime > timeout) {
          reject(new Error('Timeout vidéo'));
          return;
        }

        try {
          const status = await this.getVideoStatus(videoId);

          if (status.status === 'completed' && status.video_url) {
            resolve(status.video_url);
          } else if (status.status === 'failed') {
            reject(new Error('Échec génération vidéo'));
          } else {
            setTimeout(checkStatus, 3000);
          }
        } catch (error) {
          reject(error);
        }
      };

      checkStatus();
    });
  }

  async transcribeAudio(audioBlob) {
    const formData = new FormData();
    formData.append('audio', audioBlob);

    const response = await fetch(`${this.apiUrl}/api/stt/transcribe`, {
      method: 'POST',
      body: formData
    });

    return response.json();
  }

  clearHistory() {
    this.conversationHistory = [];
  }

  getHistory() {
    return [...this.conversationHistory];
  }
}

// Export pour utilisation
if (typeof module !== 'undefined' && module.exports) {
  module.exports = GOBAvatarClient;
}
```

### Utilisation du Client

```html
<script src="/js/gob-avatar-client.js"></script>
<script>
  // Initialiser client
  const avatarClient = new GOBAvatarClient({
    apiUrl: 'https://api.gobapps.com'
  });

  async function startConversation() {
    // Obtenir avatars
    const avatars = await avatarClient.getAvatars();
    console.log('Avatars disponibles:', avatars);

    // Envoyer message
    const result = await avatarClient.sendMessage(
      'Bonjour, comment puis-je investir?',
      avatars.data[0].id,
      {
        model: 'gpt-4o',
        systemPrompt: 'Assistant financier professionnel GOB'
      }
    );

    console.log('Réponse:', result.text);

    // Attendre vidéo
    if (result.videoJobId) {
      const videoUrl = await avatarClient.waitForVideo(result.videoJobId);
      console.log('Vidéo prête:', videoUrl);
      
      // Jouer vidéo
      const video = document.getElementById('myVideo');
      video.src = videoUrl;
      video.play();
    }
  }

  startConversation();
</script>
```

---

## 📊 Comparaison Options

| Feature | iFrame | React | Web Component | API Client |
|---------|--------|-------|---------------|------------|
| Facilité | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ |
| Personnalisation | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Performance | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Maintenance | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ |

## 🎯 Recommandation

**Pour intégration rapide dans GOB Apps:**
1. **Démarrage**: Option 1 (iFrame)
2. **Production**: Option 2 (React) ou Option 3 (Web Component)
3. **Customisation avancée**: Option 4 (API Client)

---

**GOB Apps** | Desjardins Gestion de Patrimoine
