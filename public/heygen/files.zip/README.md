# 🤖 Assistant Avatar IA - GOB Apps

Assistant conversationnel avec avatar vidéo HeyGen et intégration LLM (GPT-4o/Claude/Gemini) pour Desjardins Gestion de Patrimoine.

## 🎯 Fonctionnalités

✅ **Avatars HeyGen**
- Sélection d'avatars professionnels
- Génération vidéo à partir de texte
- Animation faciale et synchronisation labiale
- Support multi-langues

✅ **LLM Multi-Provider**
- GPT-4o (OpenAI) - Recommandé
- Claude Sonnet 4 (Anthropic) - Sécurité
- Gemini Pro (Google) - Alternative

✅ **Conversation Bidirectionnelle**
- Chat texte en temps réel
- Speech-to-Text (Whisper)
- Historique de conversation
- Gestion de sessions

✅ **Interface Professionnelle**
- Design moderne et responsive
- Contrôles vidéo intégrés
- Notifications en temps réel
- Mode sombre/clair

## 📋 Prérequis

- Node.js >= 18.0.0
- Redis (pour cache et sessions)
- Clés API:
  - HeyGen (obligatoire)
  - OpenAI ou Anthropic ou Google (au moins un)

## 🚀 Installation Rapide

### 1. Cloner et installer

```bash
# Cloner le projet
git clone https://github.com/yourusername/gob-avatar-assistant.git
cd gob-avatar-assistant

# Installer les dépendances
npm install

# Copier le fichier de configuration
cp .env.example .env
```

### 2. Configuration des clés API

Éditer `.env` et ajouter vos clés:

```env
HEYGEN_API_KEY=your_heygen_key
OPENAI_API_KEY=your_openai_key
ANTHROPIC_API_KEY=your_anthropic_key  # optionnel
GOOGLE_API_KEY=your_google_key        # optionnel
```

#### Obtenir les clés API:

**HeyGen:**
1. Créer compte sur [heygen.com](https://heygen.com)
2. Aller dans Settings → API
3. Générer nouvelle clé API

**OpenAI (GPT-4o):**
1. Compte sur [platform.openai.com](https://platform.openai.com)
2. API Keys → Create new secret key
3. Ajouter crédits de paiement

**Anthropic (Claude):**
1. Compte sur [console.anthropic.com](https://console.anthropic.com)
2. Get API Keys → Create Key

### 3. Démarrer Redis

```bash
# Mac
brew services start redis

# Ubuntu/Debian
sudo systemctl start redis

# Docker
docker run -d -p 6379:6379 redis:alpine
```

### 4. Lancer le serveur

```bash
# Mode développement (avec auto-reload)
npm run dev

# Mode production
npm start
```

Le serveur démarre sur `http://localhost:3000`

### 5. Accéder à l'interface

Ouvrir `avatar-assistant.html` dans votre navigateur ou:

```bash
# Servir avec un serveur HTTP simple
npx http-server -p 8080
```

Puis aller sur `http://localhost:8080/avatar-assistant.html`

## 📁 Structure du Projet

```
gob-avatar-assistant/
├── server.js                 # Serveur backend Express
├── avatar-assistant.html     # Interface frontend
├── package.json             # Dépendances Node.js
├── .env.example             # Template configuration
├── .env                     # Configuration (à créer)
├── README.md                # Documentation
├── public/                  # Fichiers statiques
├── logs/                    # Logs applicatifs
└── tests/                   # Tests unitaires
```

## 🔧 Configuration Avancée

### Personnalisation LLM

Dans `server.js`, modifier les prompts système:

```javascript
const systemPrompt = `Vous êtes un assistant financier pour GOB.
Répondez de manière concise (max 2-3 phrases).
Ton professionnel mais convivial.`;
```

### Choix du modèle LLM

Dans l'interface, sélectionner:
- **GPT-4o**: Meilleure polyvalence, qualité
- **Claude Sonnet**: Meilleure sécurité, éthique
- **Gemini Pro**: Alternative gratuite/économique

### Rate Limiting

Ajouter rate limiting dans `server.js`:

```javascript
const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // max 100 requêtes
});

app.use('/api/', limiter);
```

## 🧪 Tests

```bash
# Exécuter les tests
npm test

# Avec coverage
npm test -- --coverage

# Test d'un endpoint spécifique
curl http://localhost:3000/api/health
```

## 📊 Endpoints API

### HeyGen

```bash
# Lister avatars
GET /api/heygen/avatars

# Générer vidéo
POST /api/heygen/generate-video
{
  "avatar_id": "avatar_id_here",
  "text": "Bonjour, je suis votre assistant",
  "voice": "fr_fr_emma"
}

# Vérifier statut
GET /api/heygen/video-status/:videoId
```

### LLM

```bash
# Chat
POST /api/llm/chat
{
  "model": "gpt-4o",
  "messages": [
    {"role": "system", "content": "..."},
    {"role": "user", "content": "Bonjour"}
  ],
  "sessionId": "session_123"
}
```

### Speech

```bash
# Transcription audio
POST /api/stt/transcribe
Content-Type: multipart/form-data
{
  "audio": <fichier audio>
}
```

## 🔐 Sécurité

### Checklist Production

- [ ] Variables d'environnement sécurisées
- [ ] HTTPS activé (certificat SSL)
- [ ] Rate limiting configuré
- [ ] CORS restreint aux domaines autorisés
- [ ] Validation des inputs
- [ ] Logs de sécurité
- [ ] Monitoring des coûts API
- [ ] Backup Redis régulier

### Exemple CORS Production

```javascript
app.use(cors({
  origin: [
    'https://gobapps.com',
    'https://www.gobapps.com'
  ],
  credentials: true
}));
```

## 💰 Coûts Estimés

### HeyGen
- Plan Standard: ~$30-50/mois
- ~100-200 vidéos/mois incluses
- Vidéos supplémentaires: $0.30-0.50/vidéo

### OpenAI GPT-4o
- Input: ~$2.50 / 1M tokens
- Output: ~$10 / 1M tokens
- Whisper STT: $0.006 / minute

### Anthropic Claude
- Input: ~$3 / 1M tokens
- Output: ~$15 / 1M tokens

**Estimation mensuelle** (usage moyen):
- 1000 conversations/mois
- ~200 vidéos/mois
- **Total: $100-200/mois**

## 🐛 Troubleshooting

### Erreur "HEYGEN_API_KEY not found"
- Vérifier que `.env` existe
- Vérifier le nom de la variable
- Redémarrer le serveur après modification

### Vidéo ne se génère pas
- Vérifier crédits HeyGen
- Vérifier quota API
- Consulter logs: `tail -f logs/app.log`

### Redis connection refused
```bash
# Vérifier Redis
redis-cli ping
# Doit retourner PONG

# Démarrer Redis si arrêté
brew services start redis
```

### "Avatar not found"
- Appeler `/api/heygen/avatars` pour lister IDs valides
- Utiliser un `avatar_id` de la liste retournée

## 📈 Monitoring

### Logs

```bash
# Logs en temps réel
tail -f logs/app.log

# Erreurs uniquement
tail -f logs/app.log | grep ERROR
```

### Métriques Redis

```bash
redis-cli info stats
redis-cli monitor  # Activité temps réel
```

### Health Check

```bash
curl http://localhost:3000/api/health
```

## 🔄 Mises à Jour

```bash
# Vérifier dépendances obsolètes
npm outdated

# Mettre à jour
npm update

# Audit sécurité
npm audit
npm audit fix
```

## 📝 Intégration dans GOB Apps

### Option 1: iFrame

```html
<iframe 
  src="https://gobapps.com/avatar-assistant.html" 
  width="100%" 
  height="800px"
  frameborder="0">
</iframe>
```

### Option 2: Composant React

```jsx
import AvatarAssistant from './components/AvatarAssistant';

function App() {
  return (
    <AvatarAssistant 
      apiUrl="https://api.gobapps.com"
      defaultAvatar="avatar_pro_1"
    />
  );
}
```

### Option 3: Module ES6

```javascript
import { initAvatarAssistant } from './avatar-assistant.js';

initAvatarAssistant({
  containerId: 'avatar-container',
  config: { ... }
});
```

## 🤝 Support

Pour questions ou support:
- Email: support@gobapps.com
- Documentation HeyGen: [docs.heygen.com](https://docs.heygen.com)
- OpenAI Support: [platform.openai.com/docs](https://platform.openai.com/docs)

## 📄 Licence

MIT License - Desjardins Gestion de Patrimoine

---

**Développé par GOB Apps** | Desjardins Gestion de Patrimoine  
Version 1.0.0 | Dernière mise à jour: Décembre 2024
