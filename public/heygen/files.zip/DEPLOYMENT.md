# 🚀 Guide de Déploiement - Assistant Avatar GOB Apps

Guide complet pour déployer l'application en production sur différentes plateformes.

## 📋 Table des Matières

1. [Vercel (Recommandé)](#vercel)
2. [AWS EC2](#aws-ec2)
3. [Google Cloud Run](#google-cloud-run)
4. [Docker](#docker)
5. [Configuration Production](#configuration-production)

---

## 🔷 Vercel (Recommandé)

### Avantages
- Déploiement simple et rapide
- HTTPS automatique
- CDN global
- Scaling automatique
- Logs et monitoring intégrés

### Étapes de Déploiement

#### 1. Installation Vercel CLI

```bash
npm install -g vercel
```

#### 2. Login Vercel

```bash
vercel login
```

#### 3. Configuration Environnement

Dans le dashboard Vercel:
1. Aller dans Project Settings → Environment Variables
2. Ajouter toutes les variables de `.env`:

```
HEYGEN_API_KEY=xxx
OPENAI_API_KEY=xxx
ANTHROPIC_API_KEY=xxx
REDIS_HOST=xxx (utiliser Redis Cloud)
REDIS_PORT=6379
REDIS_PASSWORD=xxx
NODE_ENV=production
```

#### 4. Déploiement

```bash
# Premier déploiement
vercel

# Déploiement production
vercel --prod
```

#### 5. Configuration Redis Cloud

HeyGen et Redis nécessitent connexions externes:

**Option A: Upstash Redis (Recommandé)**

```bash
# Créer compte sur upstash.com
# Créer nouvelle database Redis
# Copier REDIS_HOST, REDIS_PORT, REDIS_PASSWORD

# Dans Vercel, ajouter:
REDIS_HOST=your-redis.upstash.io
REDIS_PORT=6379
REDIS_PASSWORD=your_password_here
```

**Option B: Redis Labs**

```bash
# Créer compte sur redis.com
# Créer nouvelle database
# Copier les credentials
```

#### 6. Custom Domain

```bash
# Ajouter domaine personnalisé
vercel domains add gobapps.com

# Configurer DNS
# Type: CNAME
# Name: avatar (ou @)
# Value: cname.vercel-dns.com
```

### URLs Finales

- Production: `https://gob-avatar-assistant.vercel.app`
- Custom: `https://avatar.gobapps.com`

---

## 🔶 AWS EC2

### Infrastructure Nécessaire

- EC2 instance (t3.medium minimum)
- ElastiCache Redis
- Application Load Balancer
- Route 53 (DNS)
- Certificate Manager (SSL)

### 1. Launch EC2 Instance

```bash
# Choisir AMI: Ubuntu Server 22.04 LTS
# Instance type: t3.medium
# Security Group: SSH (22), HTTP (80), HTTPS (443), Custom (3000)
```

### 2. Connexion et Installation

```bash
# SSH vers instance
ssh -i your-key.pem ubuntu@your-ec2-ip

# Mise à jour
sudo apt update && sudo apt upgrade -y

# Installer Node.js 18+
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Installer PM2 (process manager)
sudo npm install -g pm2

# Installer Nginx
sudo apt install -y nginx

# Installer Git
sudo apt install -y git
```

### 3. Cloner et Configurer App

```bash
# Cloner repo
git clone https://github.com/yourusername/gob-avatar-assistant.git
cd gob-avatar-assistant

# Installer dépendances
npm install --production

# Créer .env
nano .env
# Coller vos variables d'environnement
```

### 4. Configuration PM2

```bash
# Créer ecosystem.config.js
cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'gob-avatar',
    script: './server.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
};
EOF

# Démarrer app avec PM2
pm2 start ecosystem.config.js

# Auto-start au reboot
pm2 startup
pm2 save
```

### 5. Configuration Nginx

```bash
sudo nano /etc/nginx/sites-available/gob-avatar

# Coller configuration:
server {
    listen 80;
    server_name avatar.gobapps.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

# Activer site
sudo ln -s /etc/nginx/sites-available/gob-avatar /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 6. SSL avec Let's Encrypt

```bash
# Installer Certbot
sudo apt install -y certbot python3-certbot-nginx

# Obtenir certificat SSL
sudo certbot --nginx -d avatar.gobapps.com

# Renouvellement auto
sudo certbot renew --dry-run
```

### 7. ElastiCache Redis

Dans AWS Console:
1. ElastiCache → Create Redis cluster
2. Node type: cache.t3.micro (production: cache.t3.medium)
3. Subnet group: même VPC que EC2
4. Security group: autoriser port 6379 depuis EC2

```bash
# Dans .env, mettre:
REDIS_HOST=your-elasticache-endpoint.cache.amazonaws.com
REDIS_PORT=6379
```

### 8. Monitoring

```bash
# Logs PM2
pm2 logs

# Monitoring temps réel
pm2 monit

# Status
pm2 status
```

---

## 🔷 Google Cloud Run

### Avantages
- Serverless (pay-per-use)
- Auto-scaling
- Facile à déployer
- Intégration GCP

### 1. Créer Dockerfile

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 8080

ENV PORT=8080

CMD ["node", "server.js"]
```

### 2. Build et Push Image

```bash
# Installer gcloud CLI
curl https://sdk.cloud.google.com | bash

# Login
gcloud auth login
gcloud config set project YOUR_PROJECT_ID

# Build image
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/gob-avatar

# Ou avec Docker local
docker build -t gcr.io/YOUR_PROJECT_ID/gob-avatar .
docker push gcr.io/YOUR_PROJECT_ID/gob-avatar
```

### 3. Deploy sur Cloud Run

```bash
gcloud run deploy gob-avatar \
  --image gcr.io/YOUR_PROJECT_ID/gob-avatar \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars "HEYGEN_API_KEY=xxx,OPENAI_API_KEY=xxx" \
  --memory 1Gi \
  --timeout 300s
```

### 4. Redis avec Memorystore

```bash
# Créer instance Redis
gcloud redis instances create gob-redis \
  --size=1 \
  --region=us-central1 \
  --tier=basic

# Obtenir IP
gcloud redis instances describe gob-redis --region=us-central1
```

### 5. Custom Domain

```bash
# Mapper domaine
gcloud run domain-mappings create \
  --service gob-avatar \
  --domain avatar.gobapps.com \
  --region us-central1
```

---

## 🐳 Docker

### Docker Compose (Développement Local)

Créer `docker-compose.yml`:

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=development
      - REDIS_HOST=redis
      - REDIS_PORT=6379
    env_file:
      - .env
    depends_on:
      - redis
    volumes:
      - .:/app
      - /app/node_modules
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    command: redis-server --appendonly yes
    restart: unless-stopped

volumes:
  redis_data:
```

### Commandes Docker

```bash
# Build et start
docker-compose up -d

# Logs
docker-compose logs -f

# Stop
docker-compose down

# Rebuild après changements
docker-compose up -d --build
```

---

## ⚙️ Configuration Production

### 1. Variables d'Environnement Obligatoires

```env
# API Keys
HEYGEN_API_KEY=xxx
OPENAI_API_KEY=xxx

# Redis
REDIS_HOST=xxx
REDIS_PORT=6379
REDIS_PASSWORD=xxx

# Security
NODE_ENV=production
JWT_SECRET=xxxxx
```

### 2. Optimisations Performance

**server.js:**

```javascript
// Compression
const compression = require('compression');
app.use(compression());

// Caching headers
app.use((req, res, next) => {
  if (req.path.match(/\.(js|css|png|jpg|jpeg|gif|ico|svg)$/)) {
    res.setHeader('Cache-Control', 'public, max-age=31536000');
  }
  next();
});

// Rate limiting
const rateLimit = require('express-rate-limit');
app.use('/api/', rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
}));
```

### 3. Monitoring Recommandé

**Sentry (Erreurs):**

```javascript
const Sentry = require('@sentry/node');

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV
});

app.use(Sentry.Handlers.requestHandler());
app.use(Sentry.Handlers.errorHandler());
```

**Datadog (Métriques):**

```javascript
const StatsD = require('node-dogstatsd').StatsD;
const dogstatsd = new StatsD();

app.use((req, res, next) => {
  dogstatsd.increment('api.request');
  next();
});
```

### 4. Backup Redis

```bash
# Cron job pour backup quotidien
0 2 * * * redis-cli --rdb /backups/redis-$(date +\%Y\%m\%d).rdb
```

### 5. SSL/TLS

Toujours utiliser HTTPS en production:
- Vercel: automatique
- AWS: ALB + ACM
- GCP: automatique
- Self-hosted: Let's Encrypt

### 6. Logs Centralisés

```javascript
const winston = require('winston');
require('winston-daily-rotate-file');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.DailyRotateFile({
      filename: 'logs/app-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      maxSize: '20m',
      maxFiles: '14d'
    })
  ]
});
```

---

## 🔍 Checklist Pré-Déploiement

- [ ] Toutes les clés API configurées
- [ ] Redis accessible et testé
- [ ] Variables d'environnement sécurisées
- [ ] HTTPS activé
- [ ] Rate limiting configuré
- [ ] CORS restreint
- [ ] Monitoring configuré (Sentry/Datadog)
- [ ] Logs centralisés
- [ ] Backup Redis planifié
- [ ] Tests de charge effectués
- [ ] Documentation à jour

---

## 📊 Comparaison Plateformes

| Feature | Vercel | AWS EC2 | GCP Run | Docker |
|---------|--------|---------|---------|---------|
| Setup | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| Coût | $$ | $$$ | $$ | $ |
| Scaling | Auto | Manuel | Auto | Manuel |
| SSL | Auto | Manuel | Auto | Manuel |
| Monitoring | Inclus | À configurer | Inclus | À configurer |

**Recommandation:**
- **Prototypage/POC**: Vercel
- **Production (< 10k users)**: Vercel ou Cloud Run
- **Production (> 10k users)**: AWS EC2 avec ALB
- **Dev local**: Docker Compose

---

## 🆘 Support Déploiement

Questions? Contactez:
- Email: devops@gobapps.com
- Slack: #gob-avatar-support

---

**GOB Apps** | Desjardins Gestion de Patrimoine
