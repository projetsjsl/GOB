// server.js - Backend pour Assistant Avatar GOB Apps
// Node.js + Express + intégrations HeyGen & LLM

const express = require('express');
const cors = require('cors');
const multer = require('multer');
const axios = require('axios');
const FormData = require('form-data');
const Redis = require('ioredis');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Configuration middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Configuration multer pour uploads audio
const upload = multer({ 
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 } // 10MB max
});

// Configuration Redis pour cache/sessions
const redis = new Redis({
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379,
    password: process.env.REDIS_PASSWORD,
    retryStrategy: (times) => Math.min(times * 50, 2000)
});

// Configuration API
const CONFIG = {
    heygen: {
        apiKey: process.env.HEYGEN_API_KEY,
        baseUrl: 'https://api.heygen.com'
    },
    openai: {
        apiKey: process.env.OPENAI_API_KEY,
        model: 'gpt-4o'
    },
    anthropic: {
        apiKey: process.env.ANTHROPIC_API_KEY,
        model: 'claude-sonnet-4-20250514'
    },
    google: {
        apiKey: process.env.GOOGLE_API_KEY,
        model: 'gemini-pro'
    }
};

// ===========================
// UTILITAIRES
// ===========================

// Logger personnalisé
const logger = {
    info: (msg, data = {}) => console.log(`[INFO] ${msg}`, data),
    error: (msg, error) => console.error(`[ERROR] ${msg}`, error),
    warn: (msg, data = {}) => console.warn(`[WARN] ${msg}`, data)
};

// Gestion d'erreurs async
const asyncHandler = (fn) => (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
};

// Validation et sanitization
function sanitizeText(text) {
    return text
        .trim()
        .replace(/[<>]/g, '')
        .substring(0, 1000);
}

// Cache helper
async function getCached(key, ttl, fetchFn) {
    const cached = await redis.get(key);
    if (cached) return JSON.parse(cached);
    
    const data = await fetchFn();
    await redis.setex(key, ttl, JSON.stringify(data));
    return data;
}

// ===========================
// ENDPOINTS HEYGEN
// ===========================

// Lister les avatars disponibles
app.get('/api/heygen/avatars', asyncHandler(async (req, res) => {
    logger.info('Fetching HeyGen avatars');

    const avatars = await getCached('heygen:avatars', 3600, async () => {
        const response = await axios.get(`${CONFIG.heygen.baseUrl}/v2/avatars`, {
            headers: {
                'Authorization': `Bearer ${CONFIG.heygen.apiKey}`,
                'Content-Type': 'application/json'
            }
        });
        return response.data;
    });

    res.json({
        success: true,
        data: avatars.data || [],
        count: avatars.data?.length || 0
    });
}));

// Générer une vidéo avatar
app.post('/api/heygen/generate-video', asyncHandler(async (req, res) => {
    const { avatar_id, text, voice, dimension } = req.body;

    if (!avatar_id || !text) {
        return res.status(400).json({
            success: false,
            error: 'avatar_id et text sont requis'
        });
    }

    const sanitizedText = sanitizeText(text);
    
    logger.info('Generating HeyGen video', { avatar_id, textLength: sanitizedText.length });

    // Payload HeyGen API v2
    const payload = {
        video_inputs: [{
            character: {
                type: 'avatar',
                avatar_id: avatar_id,
                avatar_style: 'normal'
            },
            voice: {
                type: 'text',
                input_text: sanitizedText,
                voice_id: voice || 'en_us_amy'
            }
        }],
        dimension: dimension || {
            width: 1280,
            height: 720
        },
        aspect_ratio: '16:9',
        test: false
    };

    try {
        const response = await axios.post(
            `${CONFIG.heygen.baseUrl}/v2/video/generate`,
            payload,
            {
                headers: {
                    'Authorization': `Bearer ${CONFIG.heygen.apiKey}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        const videoData = response.data;
        const videoId = videoData.data?.video_id;

        if (!videoId) {
            throw new Error('Pas de video_id retourné par HeyGen');
        }

        // Stocker job info dans Redis
        await redis.setex(`heygen:job:${videoId}`, 3600, JSON.stringify({
            video_id: videoId,
            status: 'pending',
            created_at: new Date().toISOString(),
            avatar_id,
            text: sanitizedText
        }));

        logger.info('Video generation started', { video_id: videoId });

        res.json({
            success: true,
            job_id: videoId,
            video_id: videoId,
            message: 'Génération vidéo démarrée'
        });

    } catch (error) {
        logger.error('HeyGen API error', error.response?.data || error);
        res.status(500).json({
            success: false,
            error: 'Erreur lors de la génération vidéo',
            details: error.response?.data?.message || error.message
        });
    }
}));

// Vérifier le statut d'une vidéo
app.get('/api/heygen/video-status/:videoId', asyncHandler(async (req, res) => {
    const { videoId } = req.params;

    logger.info('Checking video status', { videoId });

    try {
        const response = await axios.get(
            `${CONFIG.heygen.baseUrl}/v1/video_status.get?video_id=${videoId}`,
            {
                headers: {
                    'Authorization': `Bearer ${CONFIG.heygen.apiKey}`
                }
            }
        );

        const statusData = response.data.data;

        // Mettre à jour cache Redis
        await redis.setex(`heygen:job:${videoId}`, 3600, JSON.stringify({
            ...statusData,
            checked_at: new Date().toISOString()
        }));

        res.json({
            success: true,
            status: statusData.status,
            video_url: statusData.video_url,
            thumbnail_url: statusData.thumbnail_url,
            duration: statusData.duration,
            error: statusData.error
        });

    } catch (error) {
        logger.error('Status check error', error.response?.data || error);
        res.status(500).json({
            success: false,
            error: 'Erreur lors de la vérification du statut',
            details: error.message
        });
    }
}));

// Webhook HeyGen (pour recevoir notifications)
app.post('/api/heygen/webhook', asyncHandler(async (req, res) => {
    const { video_id, status, video_url, error } = req.body;

    logger.info('HeyGen webhook received', { video_id, status });

    // Mettre à jour le statut dans Redis
    await redis.setex(`heygen:job:${video_id}`, 3600, JSON.stringify({
        video_id,
        status,
        video_url,
        error,
        webhook_received_at: new Date().toISOString()
    }));

    // Ici vous pouvez ajouter logique pour notifier le client via WebSocket
    // io.to(sessionId).emit('video_ready', { video_id, video_url });

    res.json({ success: true, received: true });
}));

// ===========================
// ENDPOINTS LLM
// ===========================

// Chat avec LLM (support multiple providers)
app.post('/api/llm/chat', asyncHandler(async (req, res) => {
    const { model, messages, sessionId } = req.body;

    if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({
            success: false,
            error: 'Messages invalides'
        });
    }

    logger.info('LLM chat request', { model, messageCount: messages.length });

    try {
        let response;

        // Router vers le bon provider
        if (model === 'gpt-4o' || model.startsWith('gpt-')) {
            response = await callOpenAI(messages, model);
        } else if (model.includes('claude')) {
            response = await callClaude(messages, model);
        } else if (model.includes('gemini')) {
            response = await callGemini(messages, model);
        } else {
            // Default GPT-4o
            response = await callOpenAI(messages, 'gpt-4o');
        }

        // Sauvegarder conversation dans Redis
        if (sessionId) {
            const historyKey = `session:${sessionId}:history`;
            await redis.lpush(historyKey, JSON.stringify({
                role: 'assistant',
                content: response.text,
                timestamp: new Date().toISOString()
            }));
            await redis.expire(historyKey, 86400); // 24h
        }

        res.json({
            success: true,
            response: response.text,
            model: response.model,
            usage: response.usage
        });

    } catch (error) {
        logger.error('LLM error', error);
        res.status(500).json({
            success: false,
            error: 'Erreur LLM',
            details: error.message
        });
    }
}));

// ===========================
// FONCTIONS LLM PROVIDERS
// ===========================

async function callOpenAI(messages, model = 'gpt-4o') {
    const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
            model: model,
            messages: messages,
            max_tokens: 500,
            temperature: 0.7
        },
        {
            headers: {
                'Authorization': `Bearer ${CONFIG.openai.apiKey}`,
                'Content-Type': 'application/json'
            }
        }
    );

    return {
        text: response.data.choices[0].message.content,
        model: response.data.model,
        usage: response.data.usage
    };
}

async function callClaude(messages, model = 'claude-sonnet-4-20250514') {
    // Convertir format messages pour Claude
    const systemMessages = messages.filter(m => m.role === 'system');
    const conversationMessages = messages.filter(m => m.role !== 'system');

    const response = await axios.post(
        'https://api.anthropic.com/v1/messages',
        {
            model: model,
            max_tokens: 500,
            system: systemMessages.map(m => m.content).join('\n'),
            messages: conversationMessages
        },
        {
            headers: {
                'x-api-key': CONFIG.anthropic.apiKey,
                'anthropic-version': '2023-06-01',
                'Content-Type': 'application/json'
            }
        }
    );

    return {
        text: response.data.content[0].text,
        model: response.data.model,
        usage: response.data.usage
    };
}

async function callGemini(messages, model = 'gemini-pro') {
    // Convertir format pour Gemini
    const contents = messages
        .filter(m => m.role !== 'system')
        .map(m => ({
            role: m.role === 'user' ? 'user' : 'model',
            parts: [{ text: m.content }]
        }));

    const response = await axios.post(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${CONFIG.google.apiKey}`,
        {
            contents: contents,
            generationConfig: {
                maxOutputTokens: 500,
                temperature: 0.7
            }
        },
        {
            headers: { 'Content-Type': 'application/json' }
        }
    );

    return {
        text: response.data.candidates[0].content.parts[0].text,
        model: model,
        usage: response.data.usageMetadata
    };
}

// ===========================
// ENDPOINTS SPEECH (STT/TTS)
// ===========================

// Speech-to-Text (Whisper OpenAI)
app.post('/api/stt/transcribe', upload.single('audio'), asyncHandler(async (req, res) => {
    if (!req.file) {
        return res.status(400).json({
            success: false,
            error: 'Fichier audio requis'
        });
    }

    logger.info('STT transcription request', { 
        size: req.file.size,
        mimetype: req.file.mimetype 
    });

    try {
        const formData = new FormData();
        formData.append('file', req.file.buffer, {
            filename: 'audio.wav',
            contentType: req.file.mimetype
        });
        formData.append('model', 'whisper-1');
        formData.append('language', 'fr');

        const response = await axios.post(
            'https://api.openai.com/v1/audio/transcriptions',
            formData,
            {
                headers: {
                    'Authorization': `Bearer ${CONFIG.openai.apiKey}`,
                    ...formData.getHeaders()
                }
            }
        );

        res.json({
            success: true,
            text: response.data.text,
            language: response.data.language
        });

    } catch (error) {
        logger.error('STT error', error.response?.data || error);
        res.status(500).json({
            success: false,
            error: 'Erreur de transcription',
            details: error.message
        });
    }
}));

// ===========================
// ENDPOINTS SESSION & HISTORY
// ===========================

// Récupérer historique conversation
app.get('/api/session/:sessionId/history', asyncHandler(async (req, res) => {
    const { sessionId } = req.params;
    const limit = parseInt(req.query.limit) || 50;

    const historyKey = `session:${sessionId}:history`;
    const history = await redis.lrange(historyKey, 0, limit - 1);

    res.json({
        success: true,
        sessionId,
        history: history.map(h => JSON.parse(h)),
        count: history.length
    });
}));

// Effacer historique
app.delete('/api/session/:sessionId/history', asyncHandler(async (req, res) => {
    const { sessionId } = req.params;
    
    await redis.del(`session:${sessionId}:history`);
    
    res.json({
        success: true,
        message: 'Historique effacé'
    });
}));

// ===========================
// HEALTH & MONITORING
// ===========================

app.get('/api/health', asyncHandler(async (req, res) => {
    const redisStatus = redis.status === 'ready' ? 'ok' : 'error';
    
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        services: {
            redis: redisStatus,
            heygen: CONFIG.heygen.apiKey ? 'configured' : 'missing',
            openai: CONFIG.openai.apiKey ? 'configured' : 'missing',
            claude: CONFIG.anthropic.apiKey ? 'configured' : 'missing'
        }
    });
}));

// ===========================
// GESTION ERREURS
// ===========================

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        success: false,
        error: 'Endpoint non trouvé'
    });
});

// Error handler global
app.use((err, req, res, next) => {
    logger.error('Unhandled error', err);
    
    res.status(err.status || 500).json({
        success: false,
        error: err.message || 'Erreur serveur',
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    });
});

// ===========================
// DÉMARRAGE SERVEUR
// ===========================

redis.on('error', (err) => {
    logger.error('Redis connection error', err);
});

redis.on('connect', () => {
    logger.info('Redis connected successfully');
});

app.listen(PORT, () => {
    logger.info(`🚀 Server running on port ${PORT}`);
    logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
    logger.info('Available endpoints:');
    logger.info('  - GET  /api/heygen/avatars');
    logger.info('  - POST /api/heygen/generate-video');
    logger.info('  - GET  /api/heygen/video-status/:videoId');
    logger.info('  - POST /api/llm/chat');
    logger.info('  - POST /api/stt/transcribe');
    logger.info('  - GET  /api/health');
});

module.exports = app;
